package emp;

public interface EmpService {
	String getEname(int empno);
}
