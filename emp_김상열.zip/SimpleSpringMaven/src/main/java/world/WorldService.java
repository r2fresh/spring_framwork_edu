package world;

public interface WorldService {
	String welcome(String name);
}
