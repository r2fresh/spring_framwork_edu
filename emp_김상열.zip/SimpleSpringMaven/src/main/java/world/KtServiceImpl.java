package world;

import org.springframework.stereotype.Service;

@Service(value="ktService")
public class KtServiceImpl implements WorldService{
	
	@Override
	public String welcome(String name){
		return "KT ~ :" + name;
	}
}
