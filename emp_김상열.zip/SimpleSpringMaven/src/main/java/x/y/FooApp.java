package x.y;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class FooApp {
	public static void main(String[] args){
//		Bar bar = new Bar();
//		Foo foo = new Foo(bar);
		
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		Foo foo = ctx.getBean("foo", Foo.class);
		
		foo.doFoo();
		
	}
}
