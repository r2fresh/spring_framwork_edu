package x.y;

public class Bar {
	public void doBar(){
		System.out.println("do Bar...");
	}
}
