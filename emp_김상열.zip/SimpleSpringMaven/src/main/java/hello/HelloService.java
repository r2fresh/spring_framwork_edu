package hello;

public interface HelloService {
	String greeting(String name);
}
