package emp;

public interface IEmpDao {
	String getEname(int empno);
}
