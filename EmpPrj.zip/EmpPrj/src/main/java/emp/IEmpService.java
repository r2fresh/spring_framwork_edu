package emp;

public interface IEmpService {
	String getEname(int empno);
}
